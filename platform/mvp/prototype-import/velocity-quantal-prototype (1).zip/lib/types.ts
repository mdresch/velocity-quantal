// Types for Velocity Quantal prototype

export type Role = "mentor" | "student" | "entrepreneur" | "admin"

export type FitLevel = "High" | "Medium" | "Low"

export type VerificationStatus = "verified" | "not_found" | "expired" | "pending"

export type PilotStatus = "draft" | "submitted" | "under_review" | "approved" | "rejected"

export type OpportunityStatus = "draft" | "published" | "closed" | "archived"

export interface OpportunityRequirements {
  skills: string[]
  certifications: string[]
  minExperienceYears: number
  jurisdictions: string[]
  availability: string
  deviceAccess: string[]
  internetRequired: boolean
}

export interface Opportunity {
  id: string
  title: string
  description: string
  mentorId: string
  mentorName: string
  status: OpportunityStatus
  requirements: OpportunityRequirements
  protectedActivityFlags: string[]
  compensation: string
  duration: string
  maxParticipants: number
  currentParticipants: number
  deadline?: string
  createdAt: string
  updatedAt: string
}

export interface OpportunityMatch {
  opportunityId: string
  score: number
  fitLevel: FitLevel
  matchedRequirements: string[]
  missingRequirements: string[]
  recommendations: string[]
}
// End Opportunity types

export type MentorPhase = "registration" | "credential_verification" | "active_mentoring" | "trusted_advisor"
export type StudentPhase = "onboarding" | "skill_building" | "portfolio_building" | "pilot_ready"
export type EntrepreneurPhase = "idea_stage" | "planning" | "active_pilot" | "scaling"
export type AdminPhase = "observer" | "reviewer" | "full_admin"

export type JourneyPhase = MentorPhase | StudentPhase | EntrepreneurPhase | AdminPhase

export interface PhaseGate {
  phase: JourneyPhase
  requiredFields: string[]
  optionalFields: string[]
  unlocks: string[] // Features/capabilities unlocked at this phase
  nextPhase?: JourneyPhase
  completionCriteria: string[]
}

export interface ProfileCompletion {
  currentPhase: JourneyPhase
  completedPhases: JourneyPhase[]
  completionPercentage: number
  fieldsCompleted: string[]
  fieldsPending: string[]
  nextUnlock: string
}

export interface UserProfile {
  id: string
  name: string
  email: string
  role: Role
  availability: string // e.g., "30+ hrs/week", "10-20 hrs/week", "<10 hrs/week"
  skills: string[]
  certifications: Certification[]
  experienceYears: number
  deviceAccess: string[]
  internetReliable: boolean
  willingToUpskill: boolean
  willingToPartnerLicensed: boolean
  preferredRoles: string[]
  languagePrefs: string[]
  consent: boolean
  createdAt: string
  matchResult?: MatchResult
  journeyPhase?: JourneyPhase
  profileCompletion?: ProfileCompletion
  bio?: string
  portfolioUrl?: string
  linkedinUrl?: string
  timezone?: string
  mentoringSince?: string
  specializations?: string[]
  jurisdictionsServed?: string[]
  maxMenteesPerMonth?: number
  hourlyRate?: number
  businessName?: string
  businessDescription?: string
  targetMarket?: string
  fundingStage?: string
  teamSize?: number
  pilotsCompleted?: number
  reviewsGiven?: number
  averageRating?: number
}

export interface Certification {
  id: string
  name: string
  issuer: string
  registryId: string
  issuedAt: string
  expiresAt?: string
  verified: boolean
  fileUrl?: string
}

export interface MatchResult {
  score: number
  fitLevel: FitLevel
  rationale: string[]
}

export interface Pilot {
  id: string
  title: string
  description: string
  ownerId: string
  ownerName: string
  jurisdictions: string[]
  protectedActivityFlags: string[]
  expectedKPIs: string
  status: PilotStatus
  fitBadge?: FitLevel
  createdAt: string
  updatedAt: string
  evidence: Evidence[]
  partnerFallbackNote?: string
}

export interface Evidence {
  id: string
  pilotId: string
  filename: string
  issuer: string
  registryId: string
  issuedAt: string
  expiresAt?: string
  checksum: string
  verified: VerificationStatus
  fileUrl: string
  mimeType: string
  uploadedAt: string
  reviewerNotes?: string[]
}

export interface AuditLogEntry {
  id: string
  timestamp: string
  userId: string
  userName: string
  action: string
  resourceType: "pilot" | "evidence" | "profile" | "verification"
  resourceId: string
  details: string
  pilotId?: string
}

export interface ApiResponse<T> {
  data: T
  requestId: string
  timestamp: string
}
