"use client"

import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { DashboardHeader } from "@/components/dashboard-header"
import { PilotCard } from "@/components/pilot-card"
import { PageAnnotation } from "@/components/ui-components"
import { getPilots, getOpportunities, updateOpportunity, deleteOpportunity } from "@/lib/mock-api"
import { useApp } from "@/lib/context"
import type { Pilot, Opportunity } from "@/lib/types"
import {
  ClipboardCheck,
  AlertCircle,
  CheckCircle2,
  Plus,
  Briefcase,
  Edit,
  Trash2,
  Eye,
  Send,
  MoreHorizontal,
  Users,
  DollarSign,
  Clock,
} from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

export default function MentorDashboard() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const { currentRole, currentUser } = useApp()
  const [pilots, setPilots] = useState<Pilot[]>([])
  const [opportunities, setOpportunities] = useState<Opportunity[]>([])
  const [activeTab, setActiveTab] = useState(searchParams.get("tab") || "pending")

  useEffect(() => {
    if (currentRole !== "mentor") {
      router.push("/")
      return
    }
    loadPilots()
    loadOpportunities()
  }, [currentRole, router])

  const loadPilots = async () => {
    const response = await getPilots()
    setPilots(response.data)
  }

  const loadOpportunities = async () => {
    if (!currentUser) return
    const response = await getOpportunities({ mentorId: currentUser.id })
    setOpportunities(response.data)
  }

  const pendingVerification = pilots.filter(
    (p) => p.protectedActivityFlags.length > 0 && p.evidence.some((e) => e.verified === "pending"),
  )

  const underReview = pilots.filter((p) => p.status === "under_review")
  const approved = pilots.filter((p) => p.status === "approved")

  const draftOpps = opportunities.filter((o) => o.status === "draft")
  const publishedOpps = opportunities.filter((o) => o.status === "published")

  const handleViewEvidence = (pilotId: string) => {
    router.push(`/evidence/${pilotId}`)
  }

  const handleVerify = (pilotId: string) => {
    router.push(`/verify/${pilotId}`)
  }

  const handlePublishOpportunity = async (oppId: string) => {
    await updateOpportunity(oppId, { status: "published" })
    loadOpportunities()
  }

  const handleCloseOpportunity = async (oppId: string) => {
    await updateOpportunity(oppId, { status: "closed" })
    loadOpportunities()
  }

  const handleDeleteOpportunity = async (oppId: string) => {
    await deleteOpportunity(oppId)
    loadOpportunities()
  }

  return (
    <div className="min-h-screen bg-background">
      <DashboardHeader />

      <main className="container mx-auto px-4 py-6">
        <PageAnnotation
          title="Mentor Dashboard"
          criteria={[
            "Show list of pilots in card view with status, protected-activity flag, Fit badge, jurisdiction",
            "Pending verifications section with review actions",
            "Actions: Open → Evidence viewer, Verify → License panel, Request clarification",
            "Card quick actions: Preview evidence, Download bundle",
            "NEW: Opportunities management - create, draft, publish",
          ]}
        />

        <div className="flex items-start justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold">Welcome, {currentUser?.name || "Mentor"}</h1>
            <p className="text-muted-foreground">Review pilots, verify licenses, and create opportunities</p>
          </div>
          <Button onClick={() => router.push("/opportunities/new")}>
            <Plus className="h-4 w-4 mr-2" />
            Create Opportunity
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Pending Verifications</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <AlertCircle className="h-5 w-5 text-amber-500" />
                <span className="text-2xl font-bold">{pendingVerification.length}</span>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Under Review</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <ClipboardCheck className="h-5 w-5 text-blue-500" />
                <span className="text-2xl font-bold">{underReview.length}</span>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Draft Opportunities</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <Edit className="h-5 w-5 text-gray-500" />
                <span className="text-2xl font-bold">{draftOpps.length}</span>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Published Opportunities</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <Briefcase className="h-5 w-5 text-green-500" />
                <span className="text-2xl font-bold">{publishedOpps.length}</span>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList>
            <TabsTrigger value="pending">Pending ({pendingVerification.length})</TabsTrigger>
            <TabsTrigger value="review">Under Review ({underReview.length})</TabsTrigger>
            <TabsTrigger value="opportunities">Opportunities ({opportunities.length})</TabsTrigger>
            <TabsTrigger value="all">All Pilots ({pilots.length})</TabsTrigger>
          </TabsList>

          <TabsContent value="pending" className="space-y-4">
            {pendingVerification.length === 0 ? (
              <Card>
                <CardContent className="py-8 text-center text-muted-foreground">
                  No pilots pending verification
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {pendingVerification.map((pilot) => (
                  <PilotCard
                    key={pilot.id}
                    pilot={pilot}
                    role="mentor"
                    onViewEvidence={handleViewEvidence}
                    onVerify={handleVerify}
                  />
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="review" className="space-y-4">
            {underReview.length === 0 ? (
              <Card>
                <CardContent className="py-8 text-center text-muted-foreground">No pilots under review</CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {underReview.map((pilot) => (
                  <PilotCard
                    key={pilot.id}
                    pilot={pilot}
                    role="mentor"
                    onViewEvidence={handleViewEvidence}
                    onVerify={handleVerify}
                  />
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="opportunities" className="space-y-4">
            {opportunities.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <Briefcase className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <p className="text-muted-foreground mb-4">
                    No opportunities yet. Create your first opportunity for entrepreneurs.
                  </p>
                  <Button onClick={() => router.push("/opportunities/new")}>
                    <Plus className="h-4 w-4 mr-2" />
                    Create Opportunity
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {opportunities.map((opp) => (
                  <Card key={opp.id}>
                    <CardHeader className="pb-2">
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle className="text-base">{opp.title}</CardTitle>
                          <CardDescription className="text-xs mt-1">
                            Created {new Date(opp.createdAt).toLocaleDateString()}
                          </CardDescription>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge
                            variant={
                              opp.status === "published" ? "default" : opp.status === "draft" ? "secondary" : "outline"
                            }
                          >
                            {opp.status}
                          </Badge>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-8 w-8">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => router.push(`/opportunities/${opp.id}/edit`)}>
                                <Edit className="h-4 w-4 mr-2" />
                                Edit
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => router.push(`/opportunities?selected=${opp.id}`)}>
                                <Eye className="h-4 w-4 mr-2" />
                                Preview
                              </DropdownMenuItem>
                              {opp.status === "draft" && (
                                <DropdownMenuItem onClick={() => handlePublishOpportunity(opp.id)}>
                                  <Send className="h-4 w-4 mr-2" />
                                  Publish
                                </DropdownMenuItem>
                              )}
                              {opp.status === "published" && (
                                <DropdownMenuItem onClick={() => handleCloseOpportunity(opp.id)}>
                                  <CheckCircle2 className="h-4 w-4 mr-2" />
                                  Close
                                </DropdownMenuItem>
                              )}
                              <DropdownMenuItem
                                className="text-destructive"
                                onClick={() => handleDeleteOpportunity(opp.id)}
                              >
                                <Trash2 className="h-4 w-4 mr-2" />
                                Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <p className="text-sm text-muted-foreground line-clamp-2">{opp.description}</p>
                      <div className="flex flex-wrap gap-3 text-sm">
                        <span className="flex items-center gap-1 text-muted-foreground">
                          <DollarSign className="h-3 w-3" />
                          {opp.compensation}
                        </span>
                        <span className="flex items-center gap-1 text-muted-foreground">
                          <Clock className="h-3 w-3" />
                          {opp.duration}
                        </span>
                        <span className="flex items-center gap-1 text-muted-foreground">
                          <Users className="h-3 w-3" />
                          {opp.currentParticipants}/{opp.maxParticipants}
                        </span>
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {opp.requirements.skills.slice(0, 3).map((skill) => (
                          <Badge key={skill} variant="outline" className="text-xs">
                            {skill}
                          </Badge>
                        ))}
                        {opp.requirements.skills.length > 3 && (
                          <Badge variant="outline" className="text-xs">
                            +{opp.requirements.skills.length - 3}
                          </Badge>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="all" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {pilots.map((pilot) => (
                <PilotCard
                  key={pilot.id}
                  pilot={pilot}
                  role="mentor"
                  onViewEvidence={handleViewEvidence}
                  onVerify={handleVerify}
                />
              ))}
            </div>
          </TabsContent>
        </Tabs>

        {/* Review Actions */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle className="text-lg">Review Actions</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-wrap gap-2">
            <Button variant="outline">Request Clarification</Button>
            <Button variant="outline">Bulk Approve Non-Protected</Button>
            <Button variant="outline">Export Review Summary</Button>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
