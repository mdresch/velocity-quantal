"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DashboardHeader } from "@/components/dashboard-header"
import { PageAnnotation, FitBadge } from "@/components/ui-components"
import { useApp } from "@/lib/context"
import { getOpportunities, matchAllOpportunities } from "@/lib/mock-api"
import type { Opportunity, OpportunityMatch } from "@/lib/types"
import {
  ArrowRight,
  Clock,
  Users,
  MapPin,
  Shield,
  CheckCircle2,
  XCircle,
  Lightbulb,
  DollarSign,
  Briefcase,
} from "lucide-react"

export default function OpportunitiesPage() {
  const router = useRouter()
  const { currentUser, currentRole } = useApp()
  const [opportunities, setOpportunities] = useState<Opportunity[]>([])
  const [matches, setMatches] = useState<Map<string, OpportunityMatch>>(new Map())
  const [loading, setLoading] = useState(true)
  const [selectedOpp, setSelectedOpp] = useState<string | null>(null)

  useEffect(() => {
    loadData()
  }, [currentUser])

  const loadData = async () => {
    setLoading(true)
    try {
      const oppResponse = await getOpportunities({ status: "published" })
      setOpportunities(oppResponse.data)

      if (currentUser) {
        const matchResponse = await matchAllOpportunities(currentUser)
        const matchMap = new Map<string, OpportunityMatch>()
        matchResponse.data.forEach((m) => matchMap.set(m.opportunityId, m))
        setMatches(matchMap)
      }
    } catch (error) {
      console.error("Failed to load opportunities:", error)
    } finally {
      setLoading(false)
    }
  }

  const selectedOpportunity = opportunities.find((o) => o.id === selectedOpp)
  const selectedMatch = selectedOpp ? matches.get(selectedOpp) : null

  return (
    <div className="min-h-screen bg-background">
      <DashboardHeader />

      <main className="container mx-auto px-4 py-6">
        <PageAnnotation
          title="Opportunity Browser"
          criteria={[
            "List published opportunities from mentors",
            "Match score and fit badge for each opportunity",
            "Detailed comparison view showing matched/missing requirements",
            "Recommendations for improving fit",
          ]}
        />

        <div className="mb-6">
          <h1 className="text-2xl font-bold">Browse Opportunities</h1>
          <p className="text-muted-foreground">
            Find opportunities that match your skills, experience, and certifications
          </p>
        </div>

        {!currentUser && (
          <Card className="mb-6 border-amber-200 bg-amber-50">
            <CardContent className="py-4">
              <p className="text-amber-800">
                <strong>Complete your profile</strong> to see personalized match scores for each opportunity.
              </p>
              <Button variant="outline" className="mt-2 bg-transparent" onClick={() => router.push("/profile/new")}>
                Complete Profile
              </Button>
            </CardContent>
          </Card>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Opportunities List */}
          <div className="lg:col-span-1 space-y-4">
            <h2 className="text-lg font-semibold">Available Opportunities</h2>
            {loading ? (
              <Card>
                <CardContent className="py-8 text-center text-muted-foreground">Loading...</CardContent>
              </Card>
            ) : opportunities.length === 0 ? (
              <Card>
                <CardContent className="py-8 text-center text-muted-foreground">
                  No opportunities available at this time.
                </CardContent>
              </Card>
            ) : (
              opportunities.map((opp) => {
                const match = matches.get(opp.id)
                return (
                  <Card
                    key={opp.id}
                    className={`cursor-pointer transition-all ${
                      selectedOpp === opp.id ? "ring-2 ring-primary" : "hover:border-primary/50"
                    }`}
                    onClick={() => setSelectedOpp(opp.id)}
                  >
                    <CardHeader className="pb-2">
                      <div className="flex items-start justify-between">
                        <CardTitle className="text-base">{opp.title}</CardTitle>
                        {match && <FitBadge level={match.fitLevel} showScore score={match.score} />}
                      </div>
                      <CardDescription className="text-xs">by {opp.mentorName}</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <DollarSign className="h-3 w-3" />
                          {opp.compensation}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {opp.duration}
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Users className="h-3 w-3 text-muted-foreground" />
                        <span className="text-xs text-muted-foreground">
                          {opp.currentParticipants}/{opp.maxParticipants} spots filled
                        </span>
                      </div>
                      {opp.protectedActivityFlags.length > 0 && (
                        <Badge variant="secondary" className="text-xs">
                          <Shield className="h-3 w-3 mr-1" />
                          Protected Activity
                        </Badge>
                      )}
                      {match && <Progress value={match.score} className="h-1.5 mt-2" />}
                    </CardContent>
                  </Card>
                )
              })
            )}
          </div>

          {/* Detailed Match View */}
          <div className="lg:col-span-2">
            {!selectedOpportunity ? (
              <Card className="h-full flex items-center justify-center">
                <CardContent className="py-12 text-center">
                  <Briefcase className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <p className="text-muted-foreground">Select an opportunity to see detailed match analysis</p>
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle>{selectedOpportunity.title}</CardTitle>
                      <CardDescription>Posted by {selectedOpportunity.mentorName}</CardDescription>
                    </div>
                    {selectedMatch && (
                      <div className="text-right">
                        <FitBadge level={selectedMatch.fitLevel} showScore score={selectedMatch.score} />
                        <p className="text-xs text-muted-foreground mt-1">Match Score</p>
                      </div>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Description */}
                  <div>
                    <h4 className="font-medium mb-2">Description</h4>
                    <p className="text-sm text-muted-foreground">{selectedOpportunity.description}</p>
                  </div>

                  {/* Details Grid */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                    <div className="p-3 bg-muted/50 rounded-lg">
                      <DollarSign className="h-4 w-4 text-green-600 mb-1" />
                      <p className="text-xs text-muted-foreground">Compensation</p>
                      <p className="text-sm font-medium">{selectedOpportunity.compensation}</p>
                    </div>
                    <div className="p-3 bg-muted/50 rounded-lg">
                      <Clock className="h-4 w-4 text-blue-600 mb-1" />
                      <p className="text-xs text-muted-foreground">Duration</p>
                      <p className="text-sm font-medium">{selectedOpportunity.duration}</p>
                    </div>
                    <div className="p-3 bg-muted/50 rounded-lg">
                      <Users className="h-4 w-4 text-purple-600 mb-1" />
                      <p className="text-xs text-muted-foreground">Spots</p>
                      <p className="text-sm font-medium">
                        {selectedOpportunity.maxParticipants - selectedOpportunity.currentParticipants} available
                      </p>
                    </div>
                    <div className="p-3 bg-muted/50 rounded-lg">
                      <MapPin className="h-4 w-4 text-orange-600 mb-1" />
                      <p className="text-xs text-muted-foreground">Jurisdiction</p>
                      <p className="text-sm font-medium">{selectedOpportunity.requirements.jurisdictions[0]}</p>
                    </div>
                  </div>

                  {/* Requirements */}
                  <div>
                    <h4 className="font-medium mb-2">Requirements</h4>
                    <div className="space-y-2">
                      <div className="flex flex-wrap gap-1">
                        <span className="text-sm text-muted-foreground mr-2">Skills:</span>
                        {selectedOpportunity.requirements.skills.map((skill) => (
                          <Badge key={skill} variant="outline" className="text-xs">
                            {skill}
                          </Badge>
                        ))}
                      </div>
                      <p className="text-sm">
                        <span className="text-muted-foreground">Experience:</span>{" "}
                        {selectedOpportunity.requirements.minExperienceYears}+ years
                      </p>
                      <p className="text-sm">
                        <span className="text-muted-foreground">Availability:</span>{" "}
                        {selectedOpportunity.requirements.availability}
                      </p>
                      {selectedOpportunity.requirements.certifications.length > 0 && (
                        <div className="flex flex-wrap gap-1">
                          <span className="text-sm text-muted-foreground mr-2">Certifications:</span>
                          {selectedOpportunity.requirements.certifications.map((cert) => (
                            <Badge key={cert} variant="secondary" className="text-xs">
                              {cert}
                            </Badge>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Protected Activities */}
                  {selectedOpportunity.protectedActivityFlags.length > 0 && (
                    <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <Shield className="h-4 w-4 text-amber-600" />
                        <span className="font-medium text-amber-800">Protected Activities</span>
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {selectedOpportunity.protectedActivityFlags.map((flag) => (
                          <Badge key={flag} variant="outline" className="text-xs border-amber-300 text-amber-700">
                            {flag}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Match Analysis */}
                  {selectedMatch && currentUser && (
                    <Tabs defaultValue="matched" className="mt-6">
                      <TabsList className="grid w-full grid-cols-3">
                        <TabsTrigger value="matched">Matched</TabsTrigger>
                        <TabsTrigger value="missing">Missing</TabsTrigger>
                        <TabsTrigger value="recommendations">Tips</TabsTrigger>
                      </TabsList>

                      <TabsContent value="matched" className="mt-4 space-y-2">
                        {selectedMatch.matchedRequirements.length === 0 ? (
                          <p className="text-sm text-muted-foreground">No requirements matched yet.</p>
                        ) : (
                          selectedMatch.matchedRequirements.map((req, i) => (
                            <div key={i} className="flex items-start gap-2 p-2 bg-green-50 rounded">
                              <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5" />
                              <span className="text-sm text-green-800">{req}</span>
                            </div>
                          ))
                        )}
                      </TabsContent>

                      <TabsContent value="missing" className="mt-4 space-y-2">
                        {selectedMatch.missingRequirements.length === 0 ? (
                          <p className="text-sm text-muted-foreground">You meet all requirements!</p>
                        ) : (
                          selectedMatch.missingRequirements.map((req, i) => (
                            <div key={i} className="flex items-start gap-2 p-2 bg-red-50 rounded">
                              <XCircle className="h-4 w-4 text-red-600 mt-0.5" />
                              <span className="text-sm text-red-800">{req}</span>
                            </div>
                          ))
                        )}
                      </TabsContent>

                      <TabsContent value="recommendations" className="mt-4 space-y-2">
                        {selectedMatch.recommendations.length === 0 ? (
                          <p className="text-sm text-muted-foreground">No recommendations - you're a great fit!</p>
                        ) : (
                          selectedMatch.recommendations.map((rec, i) => (
                            <div key={i} className="flex items-start gap-2 p-2 bg-blue-50 rounded">
                              <Lightbulb className="h-4 w-4 text-blue-600 mt-0.5" />
                              <span className="text-sm text-blue-800">{rec}</span>
                            </div>
                          ))
                        )}
                      </TabsContent>
                    </Tabs>
                  )}

                  {/* Actions */}
                  <div className="flex gap-2 pt-4 border-t">
                    {selectedMatch && selectedMatch.fitLevel !== "Low" ? (
                      <Button className="flex-1">
                        Apply Now
                        <ArrowRight className="h-4 w-4 ml-2" />
                      </Button>
                    ) : (
                      <Button
                        variant="outline"
                        className="flex-1 bg-transparent"
                        onClick={() => router.push("/profile/new")}
                      >
                        Improve Profile to Apply
                      </Button>
                    )}
                    <Button variant="outline">Contact Mentor</Button>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </main>
    </div>
  )
}
