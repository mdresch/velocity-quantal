"use client"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { DashboardHeader } from "@/components/dashboard-header"
import { PageAnnotation, PrivacyConsent } from "@/components/ui-components"
import { JourneyProgress } from "@/components/journey-progress"
import { useApp } from "@/lib/context"
import { skillsOptions } from "@/lib/sample-data"
import { studentPhaseGates, getPhaseName, getPhaseIndex } from "@/lib/journey-phases"
import type { StudentPhase } from "@/lib/types"
import { ArrowLeft, ArrowRight, CheckCircle2, Loader2, Unlock } from "lucide-react"

const availabilityOptions = ["30+ hrs/week", "10-20 hrs/week", "<10 hrs/week"]
const deviceOptions = ["Laptop", "Desktop", "Tablet", "Smartphone"]
const roleOptions = ["Project Lead", "Technical Contributor", "Reviewer", "Learner", "Support Assistant"]
const languageOptions = ["English", "Spanish", "French", "German", "Dutch", "Mandarin"]

export default function NewStudentProfilePage() {
  const router = useRouter()
  const { setCurrentUser } = useApp()

  const [currentPhase, setCurrentPhase] = useState<StudentPhase>("onboarding")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [formData, setFormData] = useState({
    // Phase 1: Onboarding
    name: "",
    email: "",
    availability: "",
    bio: "",
    consent: false,
    // Phase 2: Skill Building
    skills: [] as string[],
    experienceYears: 0,
    deviceAccess: [] as string[],
    internetReliable: true,
    languagePrefs: ["English"] as string[],
    preferredRoles: [] as string[],
    // Phase 3: Portfolio Building
    willingToUpskill: true,
    willingToPartnerLicensed: false,
    portfolioUrl: "",
    linkedinUrl: "",
    timezone: "",
  })

  const [errors, setErrors] = useState<Record<string, string>>({})

  const currentGate = studentPhaseGates.find((g) => g.phase === currentPhase)!
  const phaseIndex = getPhaseIndex("student", currentPhase)
  const completedPhases = studentPhaseGates.slice(0, phaseIndex).map((g) => g.phase as StudentPhase)

  const validateCurrentPhase = (): boolean => {
    const newErrors: Record<string, string> = {}

    if (currentPhase === "onboarding") {
      if (!formData.name.trim()) newErrors.name = "Name is required"
      if (!formData.email.trim()) newErrors.email = "Email is required"
      else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) newErrors.email = "Invalid email format"
      if (!formData.availability) newErrors.availability = "Select your availability"
      if (!formData.consent) newErrors.consent = "You must agree to continue"
    }

    if (currentPhase === "skill_building") {
      if (formData.skills.length < 3) newErrors.skills = "Select at least 3 skills"
      if (formData.deviceAccess.length === 0) newErrors.deviceAccess = "Select at least one device"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleAdvancePhase = () => {
    if (!validateCurrentPhase()) return

    const nextPhase = currentGate.nextPhase as StudentPhase | undefined
    if (nextPhase) {
      setCurrentPhase(nextPhase)
    } else {
      handleComplete()
    }
  }

  const handleComplete = async () => {
    setIsSubmitting(true)
    await new Promise((resolve) => setTimeout(resolve, 1500))
    router.push("/dashboard/student")
  }

  const handleSkillToggle = (skill: string) => {
    setFormData((prev) => ({
      ...prev,
      skills: prev.skills.includes(skill)
        ? prev.skills.filter((s) => s !== skill)
        : prev.skills.length < 6
          ? [...prev.skills, skill]
          : prev.skills,
    }))
  }

  const handleDeviceToggle = (device: string) => {
    setFormData((prev) => ({
      ...prev,
      deviceAccess: prev.deviceAccess.includes(device)
        ? prev.deviceAccess.filter((d) => d !== device)
        : [...prev.deviceAccess, device],
    }))
  }

  const handleRoleToggle = (role: string) => {
    setFormData((prev) => ({
      ...prev,
      preferredRoles: prev.preferredRoles.includes(role)
        ? prev.preferredRoles.filter((r) => r !== role)
        : [...prev.preferredRoles, role],
    }))
  }

  const progress = ((phaseIndex + 1) / studentPhaseGates.length) * 100

  return (
    <div className="min-h-screen bg-background">
      <DashboardHeader />

      <main className="container mx-auto px-4 py-6 max-w-2xl">
        <Button variant="ghost" className="mb-4" onClick={() => router.push("/student")}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Student Portal
        </Button>

        <PageAnnotation
          title="Student Profile - Phase-Gated Onboarding"
          criteria={[
            `Current Phase: ${getPhaseName(currentPhase)}`,
            "Progressive disclosure based on learning journey",
            "Skills and device info only requested in Skill Building phase",
            "Portfolio preferences only in Portfolio Building phase",
          ]}
        />

        {/* Journey Progress */}
        <div className="mb-6">
          <JourneyProgress
            role="student"
            currentPhase={currentPhase}
            completedPhases={completedPhases}
            completionPercentage={Math.round(progress)}
          />
        </div>

        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>{getPhaseName(currentPhase)}</CardTitle>
                <CardDescription>
                  {currentPhase === "onboarding" && "Basic information to get started"}
                  {currentPhase === "skill_building" && "Tell us about your skills and setup"}
                  {currentPhase === "portfolio_building" && "Set your growth preferences"}
                  {currentPhase === "pilot_ready" && "You are ready for advanced pilots"}
                </CardDescription>
              </div>
              <Badge variant="outline">
                Phase {phaseIndex + 1} of {studentPhaseGates.length}
              </Badge>
            </div>
          </CardHeader>

          <CardContent className="space-y-6">
            {/* Phase 1: Onboarding */}
            {currentPhase === "onboarding" && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="name">
                    Full Name <span className="text-destructive">*</span>
                  </Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData((prev) => ({ ...prev, name: e.target.value }))}
                    placeholder="Enter your full name"
                    className={errors.name ? "border-destructive" : ""}
                  />
                  {errors.name && <p className="text-sm text-destructive">{errors.name}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">
                    Email <span className="text-destructive">*</span>
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData((prev) => ({ ...prev, email: e.target.value }))}
                    placeholder="you@example.com"
                    className={errors.email ? "border-destructive" : ""}
                  />
                  {errors.email && <p className="text-sm text-destructive">{errors.email}</p>}
                </div>

                <div className="space-y-2">
                  <Label>
                    Availability <span className="text-destructive">*</span>
                  </Label>
                  <RadioGroup
                    value={formData.availability}
                    onValueChange={(value) => setFormData((prev) => ({ ...prev, availability: value }))}
                  >
                    {availabilityOptions.map((option) => (
                      <div key={option} className="flex items-center space-x-2">
                        <RadioGroupItem value={option} id={`avail-${option}`} />
                        <label htmlFor={`avail-${option}`} className="text-sm cursor-pointer">
                          {option}
                        </label>
                      </div>
                    ))}
                  </RadioGroup>
                  {errors.availability && <p className="text-sm text-destructive">{errors.availability}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="bio">Bio (Optional)</Label>
                  <Textarea
                    id="bio"
                    value={formData.bio}
                    onChange={(e) => setFormData((prev) => ({ ...prev, bio: e.target.value }))}
                    placeholder="Tell us about yourself and your learning goals..."
                    rows={3}
                  />
                </div>

                <PrivacyConsent
                  checked={formData.consent}
                  onChange={(checked) => setFormData((prev) => ({ ...prev, consent: checked }))}
                />
                {errors.consent && <p className="text-sm text-destructive">{errors.consent}</p>}
              </>
            )}

            {/* Phase 2: Skill Building */}
            {currentPhase === "skill_building" && (
              <>
                <div className="p-4 bg-muted/50 rounded-lg mb-4">
                  <div className="flex items-center gap-2 text-sm font-medium mb-2">
                    <Unlock className="h-4 w-4 text-green-500" />
                    Completing this phase unlocks:
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {currentGate.unlocks.map((unlock) => (
                      <Badge key={unlock} variant="outline" className="text-xs">
                        {unlock}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>
                    Skills (select 3-6) <span className="text-destructive">*</span>
                  </Label>
                  <p className="text-xs text-muted-foreground">Selected: {formData.skills.length}/6</p>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-48 overflow-y-auto p-2 border rounded-lg">
                    {skillsOptions.map((skill) => (
                      <div key={skill} className="flex items-center space-x-2">
                        <Checkbox
                          id={`skill-${skill}`}
                          checked={formData.skills.includes(skill)}
                          onCheckedChange={() => handleSkillToggle(skill)}
                          disabled={formData.skills.length >= 6 && !formData.skills.includes(skill)}
                        />
                        <label htmlFor={`skill-${skill}`} className="text-sm cursor-pointer truncate">
                          {skill}
                        </label>
                      </div>
                    ))}
                  </div>
                  {errors.skills && <p className="text-sm text-destructive">{errors.skills}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="experience">Years of Experience</Label>
                  <Input
                    id="experience"
                    type="number"
                    min="0"
                    max="50"
                    value={formData.experienceYears}
                    onChange={(e) =>
                      setFormData((prev) => ({ ...prev, experienceYears: Number.parseInt(e.target.value) || 0 }))
                    }
                  />
                </div>

                <div className="space-y-2">
                  <Label>
                    Device Access <span className="text-destructive">*</span>
                  </Label>
                  <div className="grid grid-cols-2 gap-2">
                    {deviceOptions.map((device) => (
                      <div key={device} className="flex items-center space-x-2">
                        <Checkbox
                          id={`device-${device}`}
                          checked={formData.deviceAccess.includes(device)}
                          onCheckedChange={() => handleDeviceToggle(device)}
                        />
                        <label htmlFor={`device-${device}`} className="text-sm cursor-pointer">
                          {device}
                        </label>
                      </div>
                    ))}
                  </div>
                  {errors.deviceAccess && <p className="text-sm text-destructive">{errors.deviceAccess}</p>}
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="internet"
                    checked={formData.internetReliable}
                    onCheckedChange={(checked) =>
                      setFormData((prev) => ({ ...prev, internetReliable: checked as boolean }))
                    }
                  />
                  <label htmlFor="internet" className="text-sm cursor-pointer">
                    I have reliable internet access
                  </label>
                </div>

                <div className="space-y-2">
                  <Label>Preferred Roles (Optional)</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {roleOptions.map((role) => (
                      <div key={role} className="flex items-center space-x-2">
                        <Checkbox
                          id={`role-${role}`}
                          checked={formData.preferredRoles.includes(role)}
                          onCheckedChange={() => handleRoleToggle(role)}
                        />
                        <label htmlFor={`role-${role}`} className="text-sm cursor-pointer">
                          {role}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            )}

            {/* Phase 3: Portfolio Building */}
            {currentPhase === "portfolio_building" && (
              <>
                <div className="p-4 bg-muted/50 rounded-lg mb-4">
                  <div className="flex items-center gap-2 text-sm font-medium mb-2">
                    <Unlock className="h-4 w-4 text-green-500" />
                    Completing this phase unlocks:
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {currentGate.unlocks.map((unlock) => (
                      <Badge key={unlock} variant="outline" className="text-xs">
                        {unlock}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="upskill"
                      checked={formData.willingToUpskill}
                      onCheckedChange={(checked) =>
                        setFormData((prev) => ({ ...prev, willingToUpskill: checked as boolean }))
                      }
                    />
                    <label htmlFor="upskill" className="text-sm cursor-pointer">
                      I am willing to learn new skills for pilot opportunities
                    </label>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="partner"
                      checked={formData.willingToPartnerLicensed}
                      onCheckedChange={(checked) =>
                        setFormData((prev) => ({ ...prev, willingToPartnerLicensed: checked as boolean }))
                      }
                    />
                    <label htmlFor="partner" className="text-sm cursor-pointer">
                      I am willing to partner with licensed professionals for protected activities
                    </label>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="portfolio">Portfolio URL (Optional)</Label>
                  <Input
                    id="portfolio"
                    value={formData.portfolioUrl}
                    onChange={(e) => setFormData((prev) => ({ ...prev, portfolioUrl: e.target.value }))}
                    placeholder="https://yourportfolio.com"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="linkedin">LinkedIn Profile (Optional)</Label>
                  <Input
                    id="linkedin"
                    value={formData.linkedinUrl}
                    onChange={(e) => setFormData((prev) => ({ ...prev, linkedinUrl: e.target.value }))}
                    placeholder="https://linkedin.com/in/yourprofile"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="timezone">Timezone (Optional)</Label>
                  <Input
                    id="timezone"
                    value={formData.timezone}
                    onChange={(e) => setFormData((prev) => ({ ...prev, timezone: e.target.value }))}
                    placeholder="e.g., America/New_York"
                  />
                </div>
              </>
            )}

            {/* Phase 4: Pilot Ready (celebration/summary) */}
            {currentPhase === "pilot_ready" && (
              <div className="text-center py-8">
                <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
                  <CheckCircle2 className="h-8 w-8 text-green-600" />
                </div>
                <h3 className="text-xl font-semibold mb-2">You are Pilot Ready!</h3>
                <p className="text-muted-foreground mb-6">
                  You have completed all required phases and can now access all student features.
                </p>
                <div className="flex flex-wrap justify-center gap-2">
                  {currentGate.unlocks.map((unlock) => (
                    <Badge key={unlock} className="bg-green-100 text-green-800 border-green-200">
                      {unlock}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            {/* Navigation */}
            <div className="flex justify-between pt-4 border-t">
              <Button
                variant="outline"
                onClick={() => {
                  const prevIndex = phaseIndex - 1
                  if (prevIndex >= 0) {
                    setCurrentPhase(studentPhaseGates[prevIndex].phase as StudentPhase)
                  }
                }}
                disabled={phaseIndex === 0}
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Previous
              </Button>

              <Button onClick={handleAdvancePhase} disabled={isSubmitting}>
                {isSubmitting ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Saving...
                  </>
                ) : currentGate.nextPhase ? (
                  <>
                    Continue to {getPhaseName(currentGate.nextPhase)}
                    <ArrowRight className="h-4 w-4 ml-2" />
                  </>
                ) : (
                  <>
                    Go to Dashboard
                    <ArrowRight className="h-4 w-4 ml-2" />
                  </>
                )}
              </Button>
            </div>

            {phaseIndex > 0 && (
              <div className="text-center pt-2">
                <Button variant="link" size="sm" onClick={() => router.push("/dashboard/student")}>
                  Save progress and continue later
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
